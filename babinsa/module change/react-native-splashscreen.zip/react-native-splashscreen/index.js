/*
* (The MIT License)
* Copyright (c) 2015-2016 YunJiang.Fang <42550564@qq.com>
* @providesModule SplashScreen
* @flow-weak
*/
'use strict';

var React = require('react-native');
var {
    NativeModules,
} = React;

module.exports = NativeModules.SplashScreen;
